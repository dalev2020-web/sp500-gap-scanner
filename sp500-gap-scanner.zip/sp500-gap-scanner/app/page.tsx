
"use client"

import { useEffect, useState } from "react"

type Stock = {
  symbol: string
  type: string
  open: number
  previousHigh?: number
  previousLow?: number
}

export default function Home() {
  const [stocks, setStocks] = useState<Stock[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch("/api/scan")
      .then((res) => res.json())
      .then((data) => {
        setStocks(data)
        setLoading(false)
      })
  }, [])

  return (
    <main style={{ padding: 24, fontFamily: "Arial" }}>
      <h1 style={{ fontSize: 32, fontWeight: "bold", marginBottom: 20 }}>
        S&P 500 Gap Scanner
      </h1>

      {loading && <p>Scanning market...</p>}

      <div style={{ display: "grid", gap: 24 }}>
        {stocks.map((stock) => (
          <div
            key={stock.symbol}
            style={{
              border: "1px solid #333",
              borderRadius: 12,
              padding: 20,
            }}
          >
            <h2 style={{ fontSize: 24, fontWeight: "bold" }}>
              {stock.symbol}
            </h2>

            <p>{stock.type}</p>

            <iframe
              src={`https://s.tradingview.com/widgetembed/?symbol=NASDAQ:${stock.symbol}&interval=15&theme=dark&style=1&timezone=America/New_York&session=regular`}
              width="100%"
              height="500"
            />
          </div>
        ))}
      </div>
    </main>
  )
}
